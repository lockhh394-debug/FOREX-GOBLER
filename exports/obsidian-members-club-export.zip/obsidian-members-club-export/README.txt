Obsidian Members Club export

This bundle contains the project source, UI/API code, generated contracts, public assets, compiled build outputs, and a development PostgreSQL export. Read EXPORT_MANIFEST.json before restoring. No secrets or environment files are included. Production was not published at export time, so there is no live production database/server snapshot. No APK artifact exists in this workspace.
